﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaScuolaElementareMenu
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int grandezzaClasse = 3;
            string[] classe = new string[grandezzaClasse];
            int scelta = 1;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("============================");
            Console.WriteLine("LA SCUOLA ELEMENTARE");
            Console.WriteLine("============================");
            Console.WriteLine();
            Console.ForegroundColor=ConsoleColor.White;
            for (int i=0; i<grandezzaClasse; i++)
            {
                do
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Quale opzione vuoi scegliere? 1 - Inserimento");
                    Console.ForegroundColor = ConsoleColor.White;
                    scelta =Convert.ToInt32(Console.ReadLine());
                } while (scelta != 1);
                Console.WriteLine("[1] - Inserimento");
                classe[i] = Console.ReadLine();

            }
            Console.ReadLine();
        }
    }
}
