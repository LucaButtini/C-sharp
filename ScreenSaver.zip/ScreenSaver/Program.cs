﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScreenSaver
{
    class Program 
    {
        static void Main(string[] args)
        {
            Random colore = new Random(); //generiamo colori randomicamente
            do
            {


                Console.BackgroundColor = (ConsoleColor)colore.Next(0, 16);
                Console.ForegroundColor = (ConsoleColor)colore.Next(0, 16);
                Console.Write('#');

            } while (!Console.KeyAvailable);
        }
    }
}
