﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace esclassenum1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Scrivere un programma in C# per
visualizzare in ordine decrescente i numeri divisibili per 5 partendo da un
numero inserito dall’utente che deve essere maggiore di 5 e minore o uguale a 200;
se l’utente inserisce un numero al di fuori di questo intervallo, il programma
deve chiedere nuovamente il numero. Al termine della visualizzazione il programma
deve chiedere all’utente se vuole inserire un nuovo numero o se il programma
deve terminare. Con risposta SI il programma chiede un nuovo numero con
risposta NO il programma termina (SI e NO possono essere scritti in maiuscolo,
minuscolo, o misto; il programma deve capire comunque)

ESEMPIO

Inserire il numero: (l’utente inserisce 3)

Numero non valido.
Inserire il numero: (l’utente inserisce 23)

Stampa:

20-15-10-5

Vuoi inserire un altro
numero? (SI/NO)  L’utente inserisce Si.

Inserire il numero:…….*/

            int numero, numeroDivisibile;
            string risposta = "";
            do
            {
                do
                {
                    Console.WriteLine("Inserisci un numero");
                    numero = Convert.ToInt32(Console.ReadLine());
                } while (numero <= 5 || numero > 200);

                for (int i = 0 ; numero  > 0; numero--)
                {
                    if (numero % 5 == 0)
                    {
                        numeroDivisibile = numero;
                        Console.WriteLine(numeroDivisibile);
                    }
                }
                Console.WriteLine("Vuoi inserire un altro numero?");
                risposta = Console.ReadLine();
            } while (risposta == "si");
            Console.ReadLine();
        }
    }
}
