﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace es2inclasse
{
    class Program
    {
        static void Main(string[] args)
        {
            /*ESERCIZIO #2
Scrivere un programma per
disegnare a video un rettangolo con base e altezza scelte dall’utente; il
programma deve verificare che le dimensioni inserite siano maggiori o uguali a
3 e minori di 30.Il programma deve chiedere all’utente se desidera disegnare
un altro rettangolo oppure se vuole terminare(con S il programma chiede di
inserire i dati per il nuovo rettangolo da disegnare, con N il programma termina
scrivendo a video “disegno finito”.
ESEMPIO.
Inserire la larghezza del rettangolo: (l’utente
scrive 2)
Larghezza non valida.Inserire la larghezza del
rettangolo: (l’utente scrive  8)
Inserire l’altezza del rettangolo: (l’utente
scrive 4)
Stampa:
            ********
            *     *
            *     *
            ********               */
            int larghezzaRettangolo = 0, altezzaRettangolo = 0;
            char risposta;
            do
            {
                do
                {
                    Console.WriteLine("Inserisci l'altezza del rettangolo");
                    altezzaRettangolo = Convert.ToInt32(Console.ReadLine());
                    if (altezzaRettangolo < 3 || altezzaRettangolo >= 30)
                    {
                        Console.WriteLine("Hai inserito un valore errato, inseriscilo di nuovo.");
                    }
                } while (altezzaRettangolo < 3 || altezzaRettangolo >= 30);



                do
                {
                    Console.WriteLine("Inserisci la larghezza del rettangolo");
                    larghezzaRettangolo = Convert.ToInt32(Console.ReadLine());
                    if (larghezzaRettangolo < 3 || larghezzaRettangolo >= 30)
                    {
                        Console.WriteLine("Hai inserito un valore errato, inseriscilo di nuovo.");
                    }
                } while (larghezzaRettangolo < 3 || larghezzaRettangolo >= 30);
                Console.WriteLine("Vuoi disegnare un altro rettangolo? Si (S), no (N)");
                risposta=Convert.ToChar(Console.ReadLine());
            } while (risposta == 'S');
            Console.ReadLine();
        }
    }
}
