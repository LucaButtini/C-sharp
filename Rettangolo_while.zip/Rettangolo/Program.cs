﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rettangolo
{//titolo del programma:
    //scopo: calcolare area e perimetro del rettangolo
    class Program 
    {
        static void Main(string[] args) 
        {
            //dichiarazione variabili
            double baseRettangolo; //se è sottolineata di verde vuol dire che l'hai dichiarata ma non usata
            double altezzaRettangolo=0; //ho messo zero dato che sono dentro l'if con quella variabile.
            double areaRettangolo;
            double perimetroRettangolo;
            char ripetere='s';
            //string msg1 = "Calcolo area "; //ogni carattere occupa un byte quanti sono i caratteri +1
            //string msg2 = " perimetro del rettangolo";
            //char car = 'e'; //tra un solo apice i caratteri
            
          
            //lettura base e altezza
            while (ripetere=='s')
            { 
            Console.Write("Inserisci il valore della base ");
            baseRettangolo = Convert.ToDouble(Console.ReadLine());
            if (baseRettangolo <= 0)
            {
               
                Console.WriteLine("Errore, la base non è valida");
            }
            else
            {
                Console.Write("Inserisci il valore dell'altezza ");
                altezzaRettangolo = Convert.ToDouble(Console.ReadLine());
                if (altezzaRettangolo<=0)
                    {
                    Console.WriteLine("Errore, l'altezza non è valida");
                }
                else
                {
                    //calcolo area 
                    areaRettangolo = baseRettangolo * altezzaRettangolo;
                    //calcolo perimetro 
                    perimetroRettangolo = (baseRettangolo * altezzaRettangolo) * 2;
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.Write("base:");
                    Console.WriteLine(baseRettangolo);
                    Console.Write("altezza:");
                    Console.WriteLine(altezzaRettangolo);
                    Console.ForegroundColor = ConsoleColor.Yellow;

                    Console.WriteLine($"area [{areaRettangolo}]-perimetro [{perimetroRettangolo}]");
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Vuoi riperere il programma? Scrivi S se vuoi ripeterelo e N se non vuoi");
                        Console.ForegroundColor = ConsoleColor.White;
                        ripetere = Convert.ToChar(Console.ReadLine());
                        Console.Clear();
                       
                    }
            }
         }


            //metodi di conversione con la classe Convert. Così  riesco ad assegnare alle variabili il valore da tastiera



            //algoritmo
            //baseRettangolo = 6.2; //il valore è definito in byte
            //altezzaRettangolo = 8.3;


            //visualizzazione risultati

            //Console.WriteLine(msg1+car+msg2); //concateno le stringhe


            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine();
            Console.WriteLine("PREMI INVIO PER CONTINUARE");
            Console.ReadLine();

        }
    }
}
