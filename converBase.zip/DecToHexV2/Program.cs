﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecToHexV2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Dato un numero in base 10 nel range 0-255 convertirlo in base 2.
            int numero, resto, baseConversione;
            double risultato = 0, peso = 0;
            do
            {
                Console.WriteLine("Inserisci un valore decimale (0-255)");
                numero = Convert.ToInt32(Console.ReadLine());
                if (numero < 0 || numero > 255)
                {
                    Console.WriteLine("Out of range,(premi invio)");
                    Console.ReadLine();
                }
            } while (numero < 0 || numero > 255);

            Console.WriteLine("Inserisci la base nella quale vuoi convertire il numero");
            baseConversione = Convert.ToInt32(Console.ReadLine());
            //Primo Metodo
            /*Console.Write("valore in base 2:");
            x = Console.CursorLeft += 8;
            //Conversione
            do
            {
                resto = numero % 2;
                numero = numero / 2;
                x = x-1;
                contabit = contabit - 1;
                Console.CursorLeft = x;
                Console.Write(resto);
            } while (contabit !=0);
            Console.CursorLeft += 7;
            Console.Write(" ");*/
            //secondo metodo
            /*do
            {
                resto = numero % 2;
                numero = numero / 2;
                risultato = resto + risultato;
                contabit--;
            } while (contabit != 0);
            Console.WriteLine(risultato);
            Console.ReadLine();*/
            //terzo metodo
            do
            {
                resto = numero % baseConversione;
                numero = numero / baseConversione;
                risultato = risultato + resto * Math.Pow(10, peso);
                peso++;
            } while (numero != 0);
            Console.WriteLine("{0:00000000}", risultato);
            Console.ReadLine();
        }
    }
}
