﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Switch_Project
{
    class Program
    {
        static void Main(string[] args)
        {
            string giornoSettimana;
            Console.WriteLine("Inserisci un giorno della settimana");
            giornoSettimana = Console.ReadLine();
            //PRIMA OPZIONE

            //if (giornoSettimana=="lunedì")
            //{
            //    Console.WriteLine("primo giorno settimana");
            //}
            //else
            //{
            //    if (giornoSettimana=="martedì")
            //    {
            //        Console.WriteLine("secondo giorno settimana");
            //    }
            //    else
            //    {
            //        if (giornoSettimana == "mercoledì")
            //        {
            //            Console.WriteLine("terzo giorno settimana");
            //        }
            //        else
            //        {
            //            if (giornoSettimana == "giovedì")
            //            {
            //                Console.WriteLine("quarto giorno settimana");
            //            }
            //            else
            //            {
            //                if (giornoSettimana == "venerdì")
            //                {
            //                    Console.WriteLine("quinto giorno settimana");
            //                }
            //                else
            //                {
            //                    if (giornoSettimana == "sabato")
            //                    {
            //                        Console.WriteLine("sesto giorno settimana");
            //                    }
            //                    else
            //                    {
            //                        if(giornoSettimana=="domenica")
            //                        {
            //                            Console.WriteLine("settimo giorno settimana");
            //                        }
            //                        else
            //                        {
            //                            Console.WriteLine("giorno non valido");
            //                        }
            //                    }
            //                }
            //            }
            //        }
            //    }
                
            //}


            //SECONDA OPZIONE 
            switch(giornoSettimana)
            {
                case ("lunedì"): //dentro al case puoi mettere tutto
                    Console.WriteLine("primo giorno settimana");
                    break;
                case ("martedì"):
                    Console.WriteLine("secondo giorno settimana");
                    break;
                case ("mercoledì"):
                    Console.WriteLine("terzo giorno settimana");
                    break;
                case ("giovedì"):
                    Console.WriteLine("quarto giorno settimana");
                    break;
                case ("venerdì"):
                    Console.WriteLine("quinto giorno settimana");
                    break;
                case ("sabato"):
                    Console.WriteLine("sesto giorno settimana");
                    break;
                case ("domenica"):
                    Console.WriteLine("settimo giorno settimana");
                    break;
                default: //vale solo se tutti gli altri non sono soddisfatti
                    Console.WriteLine("giorno non valido");
                        break;
            }
            Console.ReadLine();
        }
    }
}
