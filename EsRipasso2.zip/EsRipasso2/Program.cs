﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EsRipasso2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Inserisci la larghezza del rettangolo (minimo 3 e massimo 29): ");
                int width = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Inserisci la larghezza del rettangolo (minimo 3 e massimo 29): ");
                int height = Convert.ToInt32(Console.ReadLine());

                while (width < 3 || width >= 30 || height < 3 || height >= 30)
                {
                    Console.WriteLine("Input non valido, inserisci la larghezza del rettangolo (minimo 3 e massimo 29): ");
                    width = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Input non valido, inserisci la larghezza del rettangolo (minimo 3 e massimo 29): ");
                    height = Convert.ToInt32(Console.ReadLine());
                }

                Console.WriteLine("Il rettangolo richiesto:");
                for (int i = 0; i < height; i++)
                {
                    for (int j = 0; j < width; j++)
                    {
                        Console.Write("*");
                    }
                    Console.WriteLine();
                }

                Console.WriteLine("Vuoi disegnare un altro rettangolo? (Si/No):");
                string answer = Console.ReadLine().ToLower();

                if (answer == "no")
                {
                    Console.WriteLine("Disegno finito");
                    break;
                }
            }
        }
    }
}
